// BattleMenuViewModel.kt
package com.example.a3gamebrogemon.views.models

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicText
import androidx.compose.material3.Button
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.a3gamebrogemon.classes.Brogemon
import com.example.a3gamebrogemon.classes.Move
import com.example.a3gamebrogemon.classes.Type
import com.example.a3gamebrogemon.classes.brogemons

@Composable
fun BattleMenuScreen(selectedBrogemon: Brogemon) {
    var enemyBrogemon by remember { mutableStateOf(brogemons.random()) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(
                32.dp
            ),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Player's Brogemon Info
        Column(
            horizontalAlignment = Alignment.Start
        ) {
            Row {
                BasicText(
                    "Your Brogemon: ${selectedBrogemon.name}"
                )
            }
            Row {
                BasicText(
                    "Health: ${selectedBrogemon.health.intValue} / ${selectedBrogemon.maxHealth} (${selectedBrogemon.health.intValue * 100 / selectedBrogemon.maxHealth}%)"
                )
            }
            Row {
                BasicText(
                    "Type: ${selectedBrogemon.type.joinToString()}"
                )
            }
        }

        // Enemy's Brogemon Info
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.End,
        ) {
            Row {
                BasicText(
                    "Enemy Brogemon: ${enemyBrogemon.name}"
                )
            }
            Row {
                BasicText(
                    "Health: ${enemyBrogemon.health.intValue} / ${enemyBrogemon.maxHealth} (${enemyBrogemon.health.intValue * 100 / enemyBrogemon.maxHealth}%)"
                )
            }
            Row {
                BasicText(
                    "Type: ${enemyBrogemon.type.joinToString()}"
                )
            }
        }

        // Row of buttons of moves to the player use (Dynamically adds accordingly to how many moves the character has)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            for (i in 0 until selectedBrogemon.moves.size) {
                MoveButton(
                    defender = enemyBrogemon,
                    attacker = selectedBrogemon,
                    move = i
                )
            }
        }
    }
    if(enemyBrogemon.health.intValue <= 0) {
        enemyBrogemon = brogemons.random()
    }
}

@Composable
fun MoveButton(
    defender: Brogemon,
    attacker: Brogemon,
    move: Int
) {
    Button(
        onClick = {
            // Determine attack order based on speed
            val playerMove = attacker.moves[move]
            val enemyMove = chooseBestMove(defender, attacker) // Enemy chooses the best move
            println("chooseBestMove: " + chooseBestMove(defender, attacker))

            // Function to calculate and apply damage
            fun applyDamage(attacker: Brogemon, defender: Brogemon, move: Move) {
                val rawDamage = move.power
                val multiplier = Type.calculateDamageMultiplier(move.type, defender.type)
                val actualDamage = (rawDamage * multiplier / defender.defense).toInt().coerceAtLeast(1) // Minimum damage is 1
                defender.health.intValue = (defender.health.intValue - actualDamage)
            }

            if (attacker.speed >= defender.speed) {
                // Player attacks first
                applyDamage(attacker, defender, playerMove)
                if (defender.health.intValue > 0) {
                    // Enemy attacks only if it's still alive
                    applyDamage(defender, attacker, enemyMove)
                }
            } else {
                // Enemy attacks first
                applyDamage(defender, attacker, enemyMove)
                if (attacker.health.intValue > 0) {
                    // Player attacks only if still alive
                    applyDamage(attacker, defender, playerMove)
                }
            }
        }
    ) {
        BasicText(
            text = attacker.moves[move].name
        )
    }
}

/**
 * Chooses the best move for the enemy to exploit the player's weakness.
 */
fun chooseBestMove(enemy: Brogemon, player: Brogemon): Move {
    val playerWeakness = player.type.firstOrNull() // Player's first type as weakness

    // Ensure the weakness is passed as a Set<Type>
    val playerWeaknessSet = if (playerWeakness != null) setOf(playerWeakness) else emptySet()

    // Sort enemy's moves by potential damage
    val sortedMoves = enemy.moves.sortedByDescending { move ->
        val multiplier = Type.calculateDamageMultiplier(move.type, playerWeaknessSet)
        move.power * multiplier
    }

    // Add a small chance for randomness (e.g., 33%)
    return if ((1..100).random() <= 67) {
        sortedMoves.first()
    } else {
        enemy.moves.random()
    }
}





@Preview(
    showSystemUi = true,
    device = "spec:width=412dp,height=915dp,orientation=landscape"
)
@Composable
fun BattleMenuScreenPreview() {
    BattleMenuScreen(
        brogemons[0])
}