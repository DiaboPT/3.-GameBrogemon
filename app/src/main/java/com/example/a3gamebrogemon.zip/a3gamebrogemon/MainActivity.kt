// MainActivity.kt
package com.example.a3gamebrogemon

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.a3gamebrogemon.views.BrogemonSelectionView
import com.example.a3gamebrogemon.views.models.MainMenu


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MainMenu { navigateTo ->
                when (navigateTo) {
                    "selectBrogemon" -> startActivity(
                        Intent(this, BrogemonSelectionView::class.java)
                    )
                }
            }
        }
    }
}
